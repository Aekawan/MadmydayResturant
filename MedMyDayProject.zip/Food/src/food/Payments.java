
package food;

public class Payments {

    public static int PayCash;
    public static double Paychange;
    
   
    
   
    public void setPayCash(int pc){
      PayCash = pc;
    }
    public static int getPayCash(){
    return PayCash;
    }
    

    public void setPaychange(double pch){
      Paychange = pch;
    }
    public static double getPaychange(){
    return Paychange;
    }
    
    
    
   
   
}
